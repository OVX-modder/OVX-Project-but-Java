package ovx;

import mindustry.mod.Mod;

/** OVX Project Mod entry point for Mindustry v8 build 160.1. */
public class OVXProjectMod extends Mod {
    public OVXProjectMod() {
        super();
    }
}
