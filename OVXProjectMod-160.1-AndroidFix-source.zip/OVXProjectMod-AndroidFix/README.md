# OVX Project Mod — Mindustry v8 Build 160.1

This is the Java version of the OVX project, configured specifically for Mindustry v8 Build 160.1.

## Android + PC

The important part is that `gradle jar` produces a **desktop-only** JAR. That JAR is not suitable for Android.

Use:

```text
gradle deploy
```

with Android SDK + D8 available. This produces:

```text
build/libs/OVXProjectMod.jar
```

The resulting JAR contains the normal desktop classes and Android DEX classes and is intended for both PC and Android.

GitHub Actions is already configured in `.github/workflows/build.yml` to install Android build-tools, run `deploy`, verify the resulting JAR, and upload it as an artifact.

Target: **Mindustry v8 Build 160.1**.
